-- Read only output contract for the dashboard.
-- Replace SOURCE_* identifiers only after Snowflake schema discovery.
-- This query is intentionally not executable until approved source names are known.

/*
WITH bms_evidence AS (
    SELECT
        site_id,
        lsi_requirement_id,
        asset_id,
        evidence_record_id,
        evidence_date,
        evidence_result
    FROM SOURCE_DATABASE.SOURCE_SCHEMA.BMS_EVIDENCE
),
cgr_evidence AS (
    SELECT
        site_id,
        lsi_requirement_id,
        control_id AS asset_id,
        test_id AS evidence_record_id,
        test_date AS evidence_date,
        test_result AS evidence_result
    FROM SOURCE_DATABASE.SOURCE_SCHEMA.CGR_CONTROL_TESTS
),
combined AS (
    SELECT 'BMS' AS evidence_source, * FROM bms_evidence
    UNION ALL
    SELECT 'CGR' AS evidence_source, * FROM cgr_evidence
)
SELECT
    site_id,
    lsi_requirement_id,
    evidence_source,
    COUNT(DISTINCT evidence_record_id) AS evidence_record_count,
    MAX(evidence_date) AS latest_evidence_date,
    COUNT_IF(evidence_result = 'PASS') AS passed_record_count,
    COUNT_IF(evidence_result IN ('FAIL', 'MISSING', 'OVERDUE')) AS exception_count
FROM combined
GROUP BY 1, 2, 3
ORDER BY 1, 2, 3;
*/

-- Department traffic light output contract.
-- Workforce counts should be aggregated in Snowflake before being returned.
/*
WITH department_workforce AS (
    SELECT
        department_id,
        department_name,
        COUNT(DISTINCT worker_id) AS workforce_count
    FROM SOURCE_DATABASE.SOURCE_SCHEMA.WORKFORCE_SNAPSHOT
    WHERE department_name IN (
        'FZ Product & Delivery',
        'FZ Catapult',
        'FZ Elysia',
        'FZ Motorsport & Advanced Engineering'
    )
    GROUP BY 1, 2
),
metric_results AS (
    SELECT
        department_id,
        metric_key,
        evidence_source,
        actual_result,
        metric_direction,
        action_owner,
        due_date,
        open_action_count
    FROM SOURCE_DATABASE.SOURCE_SCHEMA.LSI_DEPARTMENT_METRICS
),
traffic_config AS (
    SELECT
        green_threshold_pct,
        amber_threshold_pct,
        metric_key,
        target_per_100_workers
    FROM SOURCE_DATABASE.SOURCE_SCHEMA.LSI_TRAFFIC_LIGHT_CONFIG
    WHERE is_current = TRUE
)
SELECT
    w.department_id,
    w.department_name,
    w.workforce_count,
    m.metric_key,
    m.evidence_source,
    m.actual_result,
    m.metric_direction,
    c.target_per_100_workers,
    c.target_per_100_workers * w.workforce_count / 100.0 AS adjusted_target,
    CASE
        WHEN m.metric_direction = 'MAXIMUM' THEN
            DIV0(c.target_per_100_workers * w.workforce_count / 100.0, m.actual_result) * 100
        ELSE
            DIV0(m.actual_result, c.target_per_100_workers * w.workforce_count / 100.0) * 100
    END AS achievement_pct,
    c.green_threshold_pct,
    c.amber_threshold_pct,
    m.action_owner,
    m.due_date,
    m.open_action_count
FROM department_workforce w
JOIN metric_results m USING (department_id)
JOIN traffic_config c USING (metric_key)
ORDER BY w.department_name, m.metric_key;
*/
