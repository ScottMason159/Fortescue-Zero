# Fortescue Zero LSI compliance dashboard

This is an interactive front end prototype for tracking Life Saving Initiative (LSI) requirements against evidence from the Building Management System (BMS) and Critical Controls Register (CGR).

## Open the prototype

Serve this folder with any local static web server, then open `index.html`. The dashboard currently uses representative records in `data.js`; it does not claim to show live compliance.

## Core workflow

- Start with the overall compliance position.
- Select a site and reporting period.
- Review requirement level evidence coverage.
- Use **Where to focus** to see the highest value next actions.
- Select any requirement to see its evidence source, owner and recommended next step.
- Open **Departments** to compare the four Fortescue Zero departments.
- Expand any department to see its metric level BMS/CGR evidence, workforce adjusted target, owner and due date.
- Use **Traffic light settings** to change thresholds and target rates per 100 workers. Prototype settings persist in the browser.

## Workforce normalised traffic lights

For minimum target measures such as training completion:

`adjusted target = target per 100 workers × workforce ÷ 100`

`achievement = actual ÷ adjusted target × 100`

For maximum target measures such as overdue actions, the achievement calculation is inverted so a lower actual count is better:

`achievement = adjusted maximum ÷ actual × 100`

Default status markers are green at 100% or above, amber from 80% to below 100%, and red below 80%. These values and the four metric target rates are configurable.

## Snowflake connection boundary

The supplied Fortescue Snowflake helper is preserved under `../reference-assets/skill/fortescue-snowflake/`. It uses browser single sign on and a named `fortescue_snowflake` connector profile. Before connecting this interface to live data:

1. Discover the approved BMS and CGR database, schema, table and column names.
2. Validate the read only source query in Snowflake.
3. Map its result to the contract in `snowflake-data-contract.sql`.
4. Replace `data.js` with a small approved API or Streamlit data layer. Do not put Snowflake credentials in browser code.

The required department data contract is included in `snowflake-data-contract.sql`. It expects workforce, metric results and configuration to be joined on the server so no sensitive individual workforce data is exposed to the browser.

## Status logic to confirm with the LSI owner

- **Compliant:** required evidence is present, current and passed.
- **Needs attention:** evidence is incomplete, approaching expiry or below the agreed threshold.
- **Major gap:** a required critical control record is absent, failed or overdue.

The final thresholds and the complete LSI requirement catalogue should be signed off before production use.
