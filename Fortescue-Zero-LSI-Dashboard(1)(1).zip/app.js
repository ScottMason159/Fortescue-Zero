const {sites, requirements, actions, departments, trafficSettings: defaultTrafficSettings} = window.LSI_DATA;
const storedSettings = (() => {
  try { return JSON.parse(localStorage.getItem("fz-lsi-traffic-settings")) || {}; }
  catch { return {}; }
})();
const state = {
  view:"Overview",
  site:"All sites",
  period:"Last 30 days",
  completed:new Set(),
  expandedDepartment:"catapult",
  expandedFocus:null,
  settings:{
    ...defaultTrafficSettings,
    ...storedSettings,
    targets:{...defaultTrafficSettings.targets,...(storedSettings.targets || {})}
  }
};
const icons = {Overview:"⌂"};
const navItems = Object.keys(icons);
const statusLabel = {compliant:"Compliant", attention:"Action required", gap:"Major gap"};
const trafficLabel = {green:"On target", amber:"Action required", red:"Below target"};

const $ = selector => document.querySelector(selector);
const filteredRequirements = () => state.site === "All sites" ? requirements : requirements.filter(r => r.site === state.site);
const filteredActions = () => (state.site === "All sites" ? actions : actions.filter(a => a.site === state.site)).filter(a => !state.completed.has(a.requirement));
const roundOne = value => Math.round(value * 10) / 10;
const formatNumber = value => Number(value).toLocaleString("en-AU", {maximumFractionDigits:1});

function init(){
  $("#primary-nav").innerHTML = navItems.map(item => `<button class="side-link ${item===state.view?"active":""}" type="button" data-view="${item}"><span class="nav-icon">${icons[item]}</span><span>${item}</span></button>`).join("");
  $("#site-filter").innerHTML = sites.map(site => `<option>${site}</option>`).join("");
  document.addEventListener("click", handleClick);
  $("#site-filter").addEventListener("change", event => {state.site=event.target.value; render();});
  $("#period-filter").addEventListener("change", event => {state.period=event.target.value; render();});
  $("#drawer-close").addEventListener("click", closeDrawer);
  $("#drawer-backdrop").addEventListener("click", closeDrawer);
  $("#settings-close").addEventListener("click", closeSettings);
  $("#settings-backdrop").addEventListener("click", closeSettings);
  $("#settings-form").addEventListener("submit", saveSettings);
  $("#reset-settings").addEventListener("click", resetSettings);
  render();
}

function handleClick(event){
  const nav = event.target.closest("[data-view]");
  if(nav){
    state.view=nav.dataset.view;
    document.querySelectorAll("[data-view]").forEach(item => item.classList.toggle("active", item.dataset.view===state.view));
    closeDrawer(); closeSettings(); render(); return;
  }
  const focus = event.target.closest("[data-focus]");
  if(focus){
    state.expandedFocus = state.expandedFocus === focus.dataset.focus ? null : focus.dataset.focus;
    render(); return;
  }
  const department = event.target.closest("[data-department]");
  if(department){
    const id = department.dataset.department;
    const closing = state.expandedDepartment === id;
    state.expandedDepartment = closing ? null : id;
    if(closing || state.expandedFocus !== id) state.expandedFocus = null;
    render(); return;
  }
  const requirement = event.target.closest("[data-requirement]");
  if(requirement){openDrawer(requirement.dataset.requirement); return;}
  if(event.target.closest("#settings-button")){openSettings(); return;}
  if(event.target.closest("#refresh-button")){
    const now=new Date();
    $("#refresh-label").textContent=`Data refreshed today, ${now.toLocaleTimeString("en-AU",{hour:"numeric",minute:"2-digit"}).toLowerCase()}`;
    toast("Dashboard data refreshed"); return;
  }
  if(event.target.closest("[data-help]")){
    toast("Open a department to see its adjusted targets, evidence and focus actions."); return;
  }
  const complete = event.target.closest("[data-complete]");
  if(complete){state.completed.add(complete.dataset.complete); closeDrawer(); render(); toast("Action marked complete in this prototype");}
}

function render(){
  updateHeader();
  const renderers = {Overview:renderDepartments};
  $("#view").innerHTML = renderers[state.view]();
}

function updateHeader(){
  const departmentView = state.view === "Overview";
  $("#page-title").textContent = "Department performance";
  $("#page-subtitle").hidden = departmentView;
  $("#page-subtitle").textContent = departmentView ? "" : "Prototype using representative data";
  $("#site-filter-label").hidden = departmentView;
  $("#workforce-filter-label").hidden = !departmentView;
  $("#settings-button").hidden = !departmentView;
  document.title = `${$("#page-title").textContent} | Fortescue Zero`;
}

function adjustedTarget(metricKey, workforce){
  return state.settings.targets[metricKey] * workforce / 100;
}

function metricAchievement(metricKey, metric, workforce){
  const target = adjustedTarget(metricKey, workforce);
  if(metric.direction === "max") return metric.actual === 0 ? 120 : target / metric.actual * 100;
  return target === 0 ? 100 : metric.actual / target * 100;
}

function departmentAchievement(department){
  const values = Object.entries(department.metrics).map(([key, metric]) => Math.min(metricAchievement(key, metric, department.workforce), 120));
  return values.reduce((sum,value)=>sum+value,0) / values.length;
}

function trafficStatus(achievement){
  if(achievement >= state.settings.greenThreshold) return "green";
  if(achievement >= state.settings.amberThreshold) return "amber";
  return "red";
}

function renderDepartments(){
  const assessed = departments.map(department => ({department, achievement:departmentAchievement(department)}));
  const counts = assessed.reduce((result,item) => {result[trafficStatus(item.achievement)]++; return result;},{green:0,amber:0,red:0});
  const totalWorkforce = departments.reduce((sum,department)=>sum+department.workforce,0);
  const overallAchievement = assessed.reduce((sum,item) => sum + item.achievement * item.department.workforce,0) / totalWorkforce;
  return `
    <section class="panel organisation-summary" aria-label="Fortescue Zero overall indicators">
      <div class="organisation-score">
        <div class="organisation-score-copy"><span class="overview-label">Fortescue Zero overview</span><strong>${roundOne(overallAchievement)}%</strong><small>Overall LSI achievement</small></div>
        <div class="organisation-progress" style="--score:${Math.min(overallAchievement,100)}"><span>${roundOne(overallAchievement)}%</span></div>
      </div>
      <div class="organisation-indicator status-green"><div class="indicator-heading"><span class="traffic-light green"></span><span class="indicator-value">${counts.green}</span></div><strong>On target</strong><small>At or above ${state.settings.greenThreshold}% achievement</small></div>
      <div class="organisation-indicator status-amber"><div class="indicator-heading"><span class="traffic-light amber"></span><span class="indicator-value">${counts.amber}</span></div><strong>Action required</strong><small>${state.settings.amberThreshold}% to ${state.settings.greenThreshold-0.1}% achievement</small></div>
      <div class="organisation-indicator status-red"><div class="indicator-heading"><span class="traffic-light red"></span><span class="indicator-value">${counts.red}</span></div><strong>Below target</strong><small>Below ${state.settings.amberThreshold}% achievement</small></div>
    </section>
    <section class="panel department-panel">
      <div class="department-panel-head"><div><h2>Department follow up</h2><p>Open a department to see its evidence, owners and next follow up points.</p></div></div>
      <div class="department-head"><span>Department</span><span>Field Leadership Target</span><span>Overdue Action Target</span><span>Hazards Raised Target</span><span>Achievement</span><span>Open actions</span><span></span></div>
      ${assessed.map(({department,achievement}) => departmentRow(department,achievement)).join("")}
    </section>
    ${renderControllableDetractors()}`;
}

function controllableDetractors(){
  const actionNames = {
    evidence:"Complete missing LSI evidence",
    controls:"Close critical control verification gaps",
    training:"Update outstanding training and competency records",
    overdue:"Close the oldest overdue actions"
  };
  return departments.flatMap(department => Object.entries(department.metrics).map(([key,metric]) => {
    const achievement = metricAchievement(key,metric,department.workforce);
    return {
      department,
      key,
      metric,
      achievement,
      gap:Math.max(0,100-achievement),
      status:trafficStatus(achievement),
      action:actionNames[key]
    };
  }))
    .filter(item => item.status !== "green")
    .sort((a,b) => b.gap-a.gap || (b.metric.oldestDays || 0)-(a.metric.oldestDays || 0))
    .slice(0,5);
}

function renderControllableDetractors(){
  const items = controllableDetractors();
  return `<section class="panel detractor-panel" aria-label="Top five controllable detractors">
    <div class="detractor-title"><div><h2>Top five controllable detractors</h2><p>Ranked by effect on achievement. Overdue actions also show the oldest days overdue.</p></div><span>${items.length} priorities</span></div>
    <div class="detractor-head"><span>Rank</span><span>Department</span><span>Detractor</span><span>Current position</span><span>Gap from target</span><span>Owner</span><span>Recommended action</span></div>
    ${items.map((item,index) => `<div class="detractor-row">
      <span class="detractor-rank">${index+1}</span>
      <strong>${item.department.name}</strong>
      <span class="detractor-name"><span class="traffic-light small ${item.status}"></span>${item.metric.label}</span>
      <span>${item.key === "overdue" ? `${formatNumber(item.metric.actual)} open, oldest ${item.metric.oldestDays} days overdue` : `${formatNumber(item.metric.actual)} actual against ${formatNumber(adjustedTarget(item.key,item.department.workforce))} target`}</span>
      <strong class="traffic-text ${item.status}">${roundOne(item.gap)} points</strong>
      <span>${item.metric.owner}</span>
      <strong>${item.action}</strong>
    </div>`).join("")}
  </section>`;
}

function departmentMetric(icon,value,name,note,colour){
  return `<div class="department-kpi"><span class="kpi-light ${colour}">${icon}</span><div><strong>${value}</strong><span>${name}</span><small>${note}</small></div></div>`;
}

function departmentRow(department,achievement){
  const status=trafficStatus(achievement);
  const expanded=state.expandedDepartment===department.id;
  return `<article class="department-item ${expanded?"expanded":""}">
    <button class="department-row" type="button" data-department="${department.id}" aria-expanded="${expanded}" aria-controls="department-${department.id}">
      <span class="department-name"><span class="traffic-light ${status}"></span><strong>${department.name}</strong></span>
      ${headlineTargetCell("Field Leadership",department.headlineTargets.fieldLeadership)}
      ${headlineTargetCell("Overdue Actions",department.headlineTargets.overdueActions)}
      ${headlineTargetCell("Hazards Raised",department.headlineTargets.hazardsRaised)}
      <strong class="traffic-text achievement-cell ${status}">${roundOne(achievement)}%</strong><span class="open-actions">${department.openActions}</span>
      <svg class="chevron ${expanded?"up":""}" viewBox="0 0 24 24" aria-hidden="true"><path d="m8 10 4 4 4-4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
    </button>
    ${expanded ? departmentDetail(department) : ""}
  </article>`;
}

function headlineTargetCell(label,target){
  const achieved = target.direction === "max" ? target.actual <= target.target : target.actual >= target.target;
  const status = achieved ? "green" : "amber";
  return `<span class="target-cell ${status}" aria-label="${label}: ${formatNumber(target.actual)} actual against ${formatNumber(target.target)} target, ${achieved ? "on target" : "action required"}"><strong>${formatNumber(target.actual)}</strong><small>Target ${formatNumber(target.target)}</small></span>`;
}

function departmentDetail(department){
  const focusOpen = state.expandedFocus === department.id;
  const focusCount = departmentFocusItems(department).length;
  return `<div class="department-detail" id="department-${department.id}">
    <div class="metric-head"><span>Metric</span><span>Source</span><span>Actual</span><span>Target setting</span><span>Adjusted target</span><span>Achievement</span><span>Status</span><span>Owner</span><span>Due date</span></div>
    ${Object.entries(department.metrics).map(([key,metric]) => departmentMetricRow(key,metric,department.workforce)).join("")}
    <div class="metric-foot"><span>Workforce source: Snowflake department headcount view</span><span>Last calculated 15 Jul 2026, 6:15am</span></div>
    <div class="department-focus">
      <button class="focus-toggle" type="button" data-focus="${department.id}" aria-expanded="${focusOpen}" aria-controls="focus-${department.id}">
        <span class="focus-toggle-copy"><strong>Where to focus</strong><small>${focusCount} ${focusCount === 1 ? "action" : "actions"} requiring action</small></span>
        <svg class="chevron ${focusOpen?"up":""}" viewBox="0 0 24 24" aria-hidden="true"><path d="m8 10 4 4 4-4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
      </button>
      ${focusOpen ? departmentFocusDetail(department) : ""}
    </div>
  </div>`;
}

function departmentFocusItems(department){
  const actionNames = {
    evidence:"Complete missing LSI evidence",
    controls:"Close critical control verification gaps",
    training:"Update outstanding training and competency records",
    overdue:"Close overdue actions"
  };
  return Object.entries(department.metrics)
    .map(([key,metric]) => {
      const achievement = metricAchievement(key,metric,department.workforce);
      return {metric,achievement,status:trafficStatus(achievement),action:actionNames[key]};
    })
    .filter(item => item.status !== "green")
    .sort((a,b) => a.achievement - b.achievement)
    .slice(0,3);
}

function departmentFocusDetail(department){
  const items = departmentFocusItems(department);
  if(!items.length) return `<div class="focus-empty" id="focus-${department.id}">No immediate focus actions. This department is on target.</div>`;
  return `<div class="focus-action-list" id="focus-${department.id}">
    <div class="focus-action-head"><span>Priority</span><span>Recommended action</span><span>Why this needs focus</span><span>Owner</span><span>Due date</span></div>
    ${items.map(item => `<div class="focus-action-row">
      <span class="focus-priority ${item.status}">${item.status === "red" ? "High" : "Medium"}</span>
      <strong>${item.action}</strong>
      <span class="focus-action-reason">${roundOne(item.achievement)}% achievement against the adjusted target. Source: ${item.metric.source}</span>
      <span>${item.metric.owner}</span>
      <strong class="focus-due">${item.metric.due}</strong>
    </div>`).join("")}
  </div>`;
}

function departmentMetricRow(key,metric,workforce){
  const target=adjustedTarget(key,workforce);
  const achievement=metricAchievement(key,metric,workforce);
  const status=trafficStatus(achievement);
  const targetLabel=metric.direction === "max" ? `Max ${state.settings.targets[key]}` : state.settings.targets[key];
  return `<div class="department-metric-row">
    <strong>${metric.label}</strong><span class="source-tag">${metric.source}</span><span>${formatNumber(metric.actual)}</span><span>${targetLabel}</span><span>${formatNumber(target)}</span>
    <strong class="traffic-text ${status}">${roundOne(achievement)}%</strong><span class="metric-status"><span class="traffic-light small ${status}"></span>${trafficLabel[status]}</span><span>${metric.owner}</span><span>${metric.due}</span>
  </div>`;
}

function renderOverview(){
  const reqs=filteredRequirements();
  const evidenced=reqs.filter(r=>r.status==="compliant").length;
  const score=Math.round(reqs.reduce((sum,r)=>sum+r.score,0)/Math.max(reqs.length,1));
  const attention=reqs.length-evidenced;
  const bms=reqs.filter(r=>r.source.includes("BMS")).length;
  const cgr=reqs.filter(r=>r.source.includes("CGR")).length;
  const act=filteredActions();
  return `
  <section class="panel summary" aria-label="Compliance summary">
    <div class="score-block"><p class="eyebrow">Overall compliance</p><div class="score-line"><div class="big-score">${score}%</div><div class="trend">↗ 8pp<small>vs prior period</small></div></div><div class="progress"><span style="width:${score}%"></span></div><div class="target">Target: 90%</div></div>
    ${metric("▣",reqs.length,"Total requirements","100% of selected scope","")}
    ${metric("✓",evidenced,"Evidenced",`${Math.round(evidenced/Math.max(reqs.length,1)*100)}% of requirements`,"green")}
    ${metric("!",attention,"Need attention",`${Math.round(attention/Math.max(reqs.length,1)*100)}% of requirements`,"amber")}
  </section>
  <section class="middle">
    <div class="panel requirements-panel"><div class="panel-head"><h2>Compliance by requirement</h2><button class="text-link" data-view="Requirements">View all</button></div><div class="table-head"><span>Requirement</span><span>Name</span><span>Evidence position</span><span>Status</span></div>${reqs.map(requirementRow).join("")}<div class="legend"><span style="--c:#08bc35">Compliant</span><span style="--c:#f59e0b">Action required</span><span style="--c:#ef3340">Major gap</span></div></div>
    <div class="panel evidence-panel"><div class="panel-head"><h2>Evidence coverage by source</h2></div>${sourceBlock("BMS",bms,reqs.length,"Building Management System data (isolations, alarms, interlocks)")}${sourceBlock("CGR",cgr,reqs.length,"Critical Controls Register data (tests, certificates, checks)")}<button class="text-link source-link" data-view="Evidence">View evidence details →</button></div>
  </section>
  <section class="bottom"><div class="panel focus-panel"><div class="focus-title"><h2>Where to focus</h2><span>Top actions to improve compliance</span></div><div class="action-head"><span>Rank</span><span>Urgency</span><span>Requirement</span><span>Action</span><span>Why this matters</span><span>Owner</span><span>Due date</span><span></span></div>${act.length?act.map(actionRow).join(""):`<div class="empty">No open actions for this site.</div>`}<button class="text-link" data-view="Actions">View all actions →</button></div><div class="panel quality-panel"><div class="panel-head"><h2>Recent data quality</h2></div><div class="quality-state"><span class="check">✓</span><span>BMS and CGR data quality looks good</span></div><p>No critical issues detected in the selected period.</p><div class="quality-meta"><div><span>Freshness</span><strong>Within 6 hours</strong></div><div><span>Matched records</span><strong>97%</strong></div><div><span>Exceptions</span><strong>3 to review</strong></div></div></div></section>`;
}

function metric(icon,value,name,note,cls){return `<div class="metric ${cls}"><div class="metric-icon">${icon}</div><div><div class="metric-number">${value}</div><div class="metric-name">${name}</div><div class="metric-note">${note}</div></div></div>`;}
function requirementRow(r){return `<div class="req-row" tabindex="0" role="button" data-requirement="${r.id}" aria-label="${r.id} ${r.name}, ${statusLabel[r.status]}"><span class="req-id">${r.id}</span><span>${r.name}</span><span class="bar ${r.status}"><span style="width:${r.score}%"></span></span><span class="status ${r.status}">${statusLabel[r.status]}</span></div>`;}
function sourceBlock(name,count,total,desc){const p=Math.round(count/Math.max(total,1)*100);return `<div class="source"><div><div class="source-name">${name}</div><div class="source-count">${count} of ${total} requirements with evidence</div><div class="source-desc">${desc}</div></div><div class="donut" style="--p:${p}"><strong>${p}%</strong></div></div>`;}
function actionRow(a){return `<div class="action-row"><span class="rank">${a.rank}</span><span class="urgency ${a.urgency.toLowerCase()}">${a.urgency}</span><span class="req-id">${a.requirement}</span><span class="action-name">${a.action}</span><span class="reason">${a.reason}</span><span class="owner"><span class="avatar">${a.initials}</span>${a.owner}</span><span class="due">${a.due}</span><button class="row-open" data-requirement="${a.requirement}" aria-label="Open ${a.requirement}">›</button></div>`;}

function renderRequirements(){const reqs=filteredRequirements();return `<div class="panel view-page"><h2>LSI requirements</h2><p>Trace each requirement from compliance position to its supporting BMS or CGR evidence.</p><table class="requirement-table"><thead><tr><th>Requirement</th><th>Name</th><th>Site</th><th>Source</th><th>Evidence</th><th>Score</th><th>Status</th><th>Owner</th></tr></thead><tbody>${reqs.map(r=>`<tr data-requirement="${r.id}"><td class="req-id">${r.id}</td><td>${r.name}</td><td>${r.site}</td><td>${r.source}</td><td>${r.evidence} records</td><td>${r.score}%</td><td><span class="status ${r.status}">${statusLabel[r.status]}</span></td><td>${r.owner}</td></tr>`).join("")}</tbody></table></div>`;}
function renderEvidence(){const reqs=filteredRequirements();return `<div class="panel view-page"><h2>Evidence register</h2><p>See which source supports each requirement and where records need review.</p><table class="requirement-table"><thead><tr><th>Requirement</th><th>Evidence source</th><th>Records found</th><th>Coverage</th><th>Latest assessment</th><th>Outcome</th></tr></thead><tbody>${reqs.map(r=>`<tr data-requirement="${r.id}"><td class="req-id">${r.id}</td><td>${r.source}</td><td>${r.evidence}</td><td>${r.score}%</td><td>15 Jul 2026</td><td><span class="status ${r.status}">${statusLabel[r.status]}</span></td></tr>`).join("")}</tbody></table></div>`;}
function renderActions(){const act=filteredActions();return `<div class="panel view-page"><h2>Compliance actions</h2><p>Prioritised follow up, with a clear owner and due date.</p>${act.length?`<table class="requirement-table"><thead><tr><th>Priority</th><th>Requirement</th><th>Action</th><th>Reason</th><th>Owner</th><th>Due date</th></tr></thead><tbody>${act.map(a=>`<tr data-requirement="${a.requirement}"><td><span class="urgency ${a.urgency.toLowerCase()}">${a.urgency}</span></td><td class="req-id">${a.requirement}</td><td><strong>${a.action}</strong></td><td>${a.reason}</td><td>${a.owner}</td><td class="due">${a.due}</td></tr>`).join("")}</tbody></table>`:`<div class="empty">All actions are complete for this site.</div>`}</div>`;}
function renderQuality(){return `<div class="panel view-page"><h2>Data quality</h2><p>Confidence checks for the BMS and CGR data used in this dashboard.</p><table class="requirement-table"><thead><tr><th>Check</th><th>Source</th><th>Position</th><th>Threshold</th><th>Outcome</th></tr></thead><tbody><tr><td>Data freshness</td><td>BMS</td><td>2 hours</td><td>Under 12 hours</td><td class="status compliant">Pass</td></tr><tr><td>Data freshness</td><td>CGR</td><td>6 hours</td><td>Under 12 hours</td><td class="status compliant">Pass</td></tr><tr><td>Asset identifier match</td><td>BMS + CGR</td><td>97%</td><td>At least 95%</td><td class="status compliant">Pass</td></tr><tr><td>Missing control test result</td><td>CGR</td><td>3 records</td><td>0 records</td><td class="status attention">Review</td></tr></tbody></table></div>`;}

function openSettings(){
  $("#green-threshold").value=state.settings.greenThreshold;
  $("#amber-threshold").value=state.settings.amberThreshold;
  Object.entries(state.settings.targets).forEach(([key,value]) => $(`#target-${key}`).value=value);
  $("#settings-drawer").classList.add("open");
  $("#settings-drawer").setAttribute("aria-hidden","false");
  $("#settings-backdrop").hidden=false;
}
function closeSettings(){$("#settings-drawer").classList.remove("open");$("#settings-drawer").setAttribute("aria-hidden","true");$("#settings-backdrop").hidden=true;}
function saveSettings(event){
  event.preventDefault();
  const green=Number($("#green-threshold").value), amber=Number($("#amber-threshold").value);
  if(green<=amber){toast("Green threshold must be higher than amber");return;}
  state.settings={greenThreshold:green,amberThreshold:amber,basis:state.settings.basis,targets:{evidence:Number($("#target-evidence").value),controls:Number($("#target-controls").value),training:Number($("#target-training").value),overdue:Number($("#target-overdue").value)}};
  localStorage.setItem("fz-lsi-traffic-settings",JSON.stringify(state.settings));
  closeSettings(); render(); toast("Traffic light settings saved and statuses recalculated");
}
function resetSettings(){state.settings={...defaultTrafficSettings,targets:{...defaultTrafficSettings.targets}};localStorage.removeItem("fz-lsi-traffic-settings");openSettings();toast("Default settings restored");}

function openDrawer(id){const r=requirements.find(item=>item.id===id);if(!r)return;const a=actions.find(item=>item.requirement===id);$("#drawer-content").innerHTML=`<div class="req-id">${r.id}</div><h2>${r.name}</h2><span class="drawer-status status ${r.status}">${statusLabel[r.status]}</span><p>${r.detail}</p><div class="detail-grid"><div><span>Compliance score</span><strong>${r.score}%</strong></div><div><span>Evidence source</span><strong>${r.source}</strong></div><div><span>Records found</span><strong>${r.evidence}</strong></div><div><span>Site</span><strong>${r.site}</strong></div><div><span>Owner</span><strong>${r.owner}</strong></div><div><span>Due date</span><strong>${r.due}</strong></div></div>${a&&!state.completed.has(id)?`<h3>Recommended next action</h3><p><strong>${a.action}</strong><br>${a.reason}</p><button class="primary-button" data-complete="${id}">Mark action complete</button>`:""}`;$("#drawer").classList.add("open");$("#drawer").setAttribute("aria-hidden","false");$("#drawer-backdrop").hidden=false;}
function closeDrawer(){$("#drawer").classList.remove("open");$("#drawer").setAttribute("aria-hidden","true");$("#drawer-backdrop").hidden=true;}
function toast(message){const element=$("#toast");element.textContent=message;element.classList.add("show");clearTimeout(window.toastTimer);window.toastTimer=setTimeout(()=>element.classList.remove("show"),2600);}

init();
