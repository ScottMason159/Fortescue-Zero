window.LSI_DATA = {
  sites: ["All sites", "Kidlington", "Banbury", "Perth operations"],
  requirements: [
    {id:"LSI-01", name:"Isolation design", status:"compliant", score:96, source:"BMS", site:"Kidlington", evidence:18, owner:"Engineering assurance", due:"Complete", detail:"Isolation design records are current and linked to the controlled asset register."},
    {id:"LSI-02", name:"Isolation verification", status:"attention", score:68, source:"BMS", site:"Kidlington", evidence:9, owner:"Jamie Brown", due:"22 Jul 2026", detail:"Four assets have no completed isolation verification record in the reporting period."},
    {id:"LSI-03", name:"Energy control procedures", status:"compliant", score:94, source:"BMS", site:"Banbury", evidence:22, owner:"Operations", due:"Complete", detail:"Controlled procedures are approved and within their review dates."},
    {id:"LSI-04", name:"Training and competency", status:"attention", score:67, source:"BMS + CGR", site:"Banbury", evidence:31, owner:"Lisa Morgan", due:"29 Jul 2026", detail:"Twelve people have expired or missing competency records for relevant work groups."},
    {id:"LSI-05", name:"Access and authorisation", status:"compliant", score:91, source:"BMS", site:"Perth operations", evidence:42, owner:"Site operations", due:"Complete", detail:"Access and authorisation checks meet the required evidence threshold."},
    {id:"LSI-06", name:"Audit and assurance", status:"compliant", score:90, source:"CGR", site:"Perth operations", evidence:8, owner:"Risk and assurance", due:"Complete", detail:"Planned assurance activities are complete for the selected period."},
    {id:"LSI-07", name:"Change management", status:"compliant", score:93, source:"BMS", site:"Kidlington", evidence:14, owner:"Engineering", due:"Complete", detail:"Changes affecting stored energy controls have recorded assessments and approvals."},
    {id:"LSI-08", name:"Control of stored energy", status:"gap", score:52, source:"BMS + CGR", site:"Banbury", evidence:6, owner:"Andrew Nguyen", due:"24 Jul 2026", detail:"Two critical stored energy controls do not have current effectiveness evidence."},
    {id:"LSI-09", name:"Communication and signage", status:"compliant", score:97, source:"BMS", site:"Perth operations", evidence:25, owner:"Facilities", due:"Complete", detail:"Signage inspections and communication records are complete."},
    {id:"LSI-10", name:"Emergency preparedness", status:"compliant", score:92, source:"BMS", site:"Kidlington", evidence:11, owner:"Emergency management", due:"Complete", detail:"Emergency response checks are current and exceptions are closed."},
    {id:"LSI-11", name:"Control verification", status:"gap", score:48, source:"CGR", site:"Banbury", evidence:5, owner:"Andrew Nguyen", due:"24 Jul 2026", detail:"Three critical control tests in CGR are missing a result or supporting certificate."},
    {id:"LSI-12", name:"Management review", status:"compliant", score:89, source:"CGR", site:"Perth operations", evidence:7, owner:"Zero leadership", due:"Complete", detail:"The latest review is recorded with decisions and assigned follow up actions."}
  ],
  actions: [
    {rank:1, urgency:"High", requirement:"LSI-02", action:"Complete isolation verification evidence", reason:"Isolation verifications are missing or overdue for 4 assets.", owner:"Jamie Brown", initials:"JB", due:"22 Jul 2026", site:"Kidlington"},
    {rank:2, urgency:"Medium", requirement:"LSI-04", action:"Review overdue competency records", reason:"12 people have expired or missing competency records.", owner:"Lisa Morgan", initials:"LM", due:"29 Jul 2026", site:"Banbury"},
    {rank:3, urgency:"High", requirement:"LSI-11", action:"Resolve missing CGR control test", reason:"3 critical control tests are missing results in CGR.", owner:"Andrew Nguyen", initials:"AN", due:"24 Jul 2026", site:"Banbury"}
  ],
  trafficSettings: {
    greenThreshold: 100,
    amberThreshold: 80,
    basis: "per100",
    targets: {
      evidence: 85,
      controls: 90,
      training: 95,
      overdue: 5
    }
  },
  departments: [
    {
      id:"product-delivery", name:"FZ Product & Delivery", workforce:512, openActions:3,
      owner:"Alex Morgan", due:"31 Jul 2026",
      headlineTargets:{fieldLeadership:{actual:48,target:45,direction:"min"},overdueActions:{actual:18,target:26,direction:"max"},hazardsRaised:{actual:68,target:60,direction:"min"}},
      metrics:{
        evidence:{label:"LSI evidence coverage", source:"BMS", actual:459, direction:"min", owner:"Sarah Johnson", due:"22 Jul 2026"},
        controls:{label:"Critical control verification", source:"CGR", actual:446, direction:"min", owner:"Michael Chen", due:"24 Jul 2026"},
        training:{label:"Training and competency", source:"BMS", actual:501, direction:"min", owner:"Priya Nair", due:"25 Jul 2026"},
        overdue:{label:"Overdue actions", source:"CGR", actual:18, direction:"max", owner:"David Wilson", due:"18 Jul 2026", oldestDays:14}
      }
    },
    {
      id:"catapult", name:"FZ Catapult", workforce:318, openActions:7,
      owner:"Sarah Johnson", due:"22 Jul 2026",
      headlineTargets:{fieldLeadership:{actual:22,target:28,direction:"min"},overdueActions:{actual:22,target:16,direction:"max"},hazardsRaised:{actual:31,target:38,direction:"min"}},
      metrics:{
        evidence:{label:"LSI evidence coverage", source:"BMS", actual:222, direction:"min", owner:"Sarah Johnson", due:"22 Jul 2026"},
        controls:{label:"Critical control verification", source:"CGR", actual:218, direction:"min", owner:"Michael Chen", due:"18 Jul 2026"},
        training:{label:"Training and competency", source:"BMS", actual:287, direction:"min", owner:"Priya Nair", due:"25 Jul 2026"},
        overdue:{label:"Overdue actions", source:"CGR", actual:22, direction:"max", owner:"David Wilson", due:"18 Jul 2026", oldestDays:38}
      }
    },
    {
      id:"elysia", name:"FZ Elysia", workforce:276, openActions:4,
      owner:"Lisa Morgan", due:"29 Jul 2026",
      headlineTargets:{fieldLeadership:{actual:30,target:26,direction:"min"},overdueActions:{actual:17,target:14,direction:"max"},hazardsRaised:{actual:29,target:32,direction:"min"}},
      metrics:{
        evidence:{label:"LSI evidence coverage", source:"BMS", actual:225, direction:"min", owner:"Nina Patel", due:"25 Jul 2026"},
        controls:{label:"Critical control verification", source:"CGR", actual:236, direction:"min", owner:"Paul Reid", due:"25 Jul 2026"},
        training:{label:"Training and competency", source:"BMS", actual:247, direction:"min", owner:"Lisa Morgan", due:"29 Jul 2026"},
        overdue:{label:"Overdue actions", source:"CGR", actual:17, direction:"max", owner:"Ava Smith", due:"26 Jul 2026", oldestDays:21}
      }
    },
    {
      id:"motorsport-engineering", name:"FZ Motorsport & Advanced Engineering", workforce:142, openActions:9,
      owner:"Andrew Nguyen", due:"24 Jul 2026",
      headlineTargets:{fieldLeadership:{actual:9,target:14,direction:"min"},overdueActions:{actual:16,target:7,direction:"max"},hazardsRaised:{actual:12,target:18,direction:"min"}},
      metrics:{
        evidence:{label:"LSI evidence coverage", source:"BMS", actual:91, direction:"min", owner:"Tom Baker", due:"20 Jul 2026"},
        controls:{label:"Critical control verification", source:"CGR", actual:88, direction:"min", owner:"Andrew Nguyen", due:"24 Jul 2026"},
        training:{label:"Training and competency", source:"BMS", actual:111, direction:"min", owner:"Emma Jones", due:"22 Jul 2026"},
        overdue:{label:"Overdue actions", source:"CGR", actual:16, direction:"max", owner:"Jack Lee", due:"18 Jul 2026", oldestDays:46}
      }
    }
  ]
};
